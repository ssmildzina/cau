<?php

namespace Illuminate\Database;

use Illuminate\Support\ConfigurationUrlParser as BaseConfigurationUrlParser;

class ConfigurationUrlParser extends BaseConfigurationUrlParser
{
    //
}
